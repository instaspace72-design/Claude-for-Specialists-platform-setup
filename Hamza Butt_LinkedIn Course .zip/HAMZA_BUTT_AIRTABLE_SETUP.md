# 🗂️ HAMZA BUTT - AIRTABLE SETUP GUIDE

**Status:** ✅ Complete setup instructions for INST005  
**Date Created:** July 14, 2026  
**Intern:** Hamza Butt  
**Email:** hamza@myinstaspace.com  
**Login:** INST005  
**Password:** Instaspace@123hb (change on first login)

---

## 📋 AIRTABLE BASE STRUCTURE

**Base Name:** InstaSpace Intern Learning Platform  
**Table Used:** Interns, Courses, Lessons, Exercises, Intern Progress

---

## 1️⃣ INTERNS TABLE - NEW ENTRY

**Create new record in "Interns" table:**

```
Field Name                 | Value
---------------------------|----------------------------------
Name                       | Hamza Butt
Email                      | hamza@myinstaspace.com
Intern ID                  | INST005
Password (Encrypted)       | Instaspace@123hb
Department                 | Growth Marketing
Role                       | LinkedIn Marketing Specialist
Start Date                 | Aug 1, 2026 (or next cohort)
End Date                   | Sept 30, 2026 (90-day program)
Reporting Manager          | Sanwa Ali
Primary Mentor             | Sanwa Ali
Secondary Mentor           | Hamza Dar
Skills Focus               | LinkedIn, Lead Generation, B2B Marketing
Learning Tracks            | LinkedIn Marketing Mastery
Status                     | Active
Cohort                     | Summer 2026 - Growth Track
Time Commitment            | Full-time (July 15 - Sept 30)
Office Hours               | 1 PM - 1:30 PM daily
Attendance Target          | 100% (5/5 days required)
Performance Track?         | Yes (daily updates to leadership)
LinkedIn Profile           | [Hamza's LinkedIn URL]
GitHub/Portfolio           | [Optional]
Notes                      | Brand new intern, high potential, growth focus
```

---

## 2️⃣ COURSES TABLE - LINKEDIN MARKETING ENTRY

**Create new record in "Courses" table:**

```
Field Name                 | Value
---------------------------|----------------------------------
Course Name                | LinkedIn Marketing Mastery
Course Code                | LNKD-001
Department                 | Growth Marketing
Level                      | Intermediate (builds on general knowledge)
Duration (Days)            | 5
Duration (Hours)           | 10 (2 hours/day)
Instructor                 | Sanwa Ali (primary), Hamza Dar (secondary)
Start Date                 | Aug 1, 2026
End Date                   | Aug 5, 2026
Schedule                   | Mon-Fri, 10 AM - 12 PM
Capstone Project?          | Yes
Capstone Title             | 90-Day LinkedIn Marketing Strategy
Capstone Pages             | 25
Prerequisites              | General marketing knowledge
Learning Outcomes          | Master LinkedIn for B2B lead generation
Target Audience            | LinkedIn Marketing Specialists, Growth Interns
Assigned Interns           | Hamza Butt (INST005)
Content Status             | Complete + Production Ready
Resource Link              | CLAUDE_FOR_SPECIALISTS_LINKEDIN_MARKETING_HAMZA_BUTT.md
Course Materials Link      | /mnt/user-data/outputs/CLAUDE_FOR_SPECIALISTS_LINKEDIN_MARKETING_HAMZA_BUTT.md
Assessments                | Daily exercises (5) + Capstone (1)
Total Exercises            | 10 (2 per day)
Success Criteria           | Capstone score 8.5/10, all templates completed
Office Hours Time          | 1 PM - 1:30 PM daily
Zoom Link                  | [Insert meeting link]
Recording Available?       | Yes
Archive After              | Sept 30, 2026
Notes                      | New course, high ROI potential ($1.5M+ pipeline)
```

---

## 3️⃣ LESSONS TABLE - COURSE BREAKDOWN

**Create 5 records in "Lessons" table (one per day):**

### **Lesson 1: LinkedIn Strategy for B2B Real Estate**

```
Field Name                 | Value
---------------------------|----------------------------------
Lesson Title               | LinkedIn Strategy for B2B Real Estate
Lesson Code                | LNKD-001-L1
Course                     | LinkedIn Marketing Mastery
Day Number                 | 1
Duration (Minutes)         | 120
Learning Objectives        | Understand LinkedIn algorithm, identify target audience, develop positioning
Key Concepts               | Algorithm factors, audience personas, competitive analysis, content pillars
Exercises Count            | 2
Exercise 1 Title           | LinkedIn Algorithm Mastery
Exercise 2 Title           | Competitive Landscape + Content Gap Analysis
Claude Prompt Included?    | Yes (detailed prompts provided)
Deliverable                | Strategy foundation (5 pages)
Success Criteria           | Clear algorithm understanding, 3 personas, 5 pillars, positioning defined
Office Hours Time          | 1 PM - 1:30 PM
Mentor Lead                | Sanwa Ali
Difficulty Level           | Intermediate
Status                     | Complete
Resource Link              | CLAUDE_FOR_SPECIALISTS_LINKEDIN_MARKETING_HAMZA_BUTT.md (Day 1 section)
```

---

### **Lesson 2: Personal Brand & Thought Leadership**

```
Field Name                 | Value
---------------------------|----------------------------------
Lesson Title               | Personal Brand & Thought Leadership
Lesson Code                | LNKD-001-L2
Course                     | LinkedIn Marketing Mastery
Day Number                 | 2
Duration (Minutes)         | 120
Learning Objectives        | Build personal brand, position as thought leader, develop content strategy
Key Concepts               | Profile optimization, positioning, thought leadership, content pillars
Exercises Count            | 2
Exercise 1 Title           | LinkedIn Profile Optimization
Exercise 2 Title           | Thought Leadership Positioning
Deliverable                | Optimized profile + 3-month content calendar
Success Criteria           | Profile fully optimized, positioning clear, calendar specific
Office Hours Time          | 1 PM - 1:30 PM
Mentor Lead                | Sanwa Ali
Difficulty Level           | Intermediate
Status                     | Complete
Resource Link              | CLAUDE_FOR_SPECIALISTS_LINKEDIN_MARKETING_HAMZA_BUTT.md (Day 2 section)
```

---

### **Lesson 3: Content Creation & Posting Strategy**

```
Field Name                 | Value
---------------------------|----------------------------------
Lesson Title               | Content Creation & Posting Strategy
Lesson Code                | LNKD-001-L3
Course                     | LinkedIn Marketing Mastery
Day Number                 | 3
Duration (Minutes)         | 120
Learning Objectives        | Master LinkedIn copywriting, create high-engagement posts, develop workflow
Key Concepts               | Copywriting, post structure, production workflow, analytics
Exercises Count            | 2
Exercise 1 Title           | LinkedIn Copywriting Mastery
Exercise 2 Title           | Content Production Workflow
Deliverable                | 20 LinkedIn posts + workflow system
Success Criteria           | 20 posts ready to post, workflow documented, analytics tracked
Office Hours Time          | 1 PM - 1:30 PM
Mentor Lead                | Sanwa Ali + Hamza Dar
Difficulty Level           | Intermediate
Status                     | Complete
Resource Link              | CLAUDE_FOR_SPECIALISTS_LINKEDIN_MARKETING_HAMZA_BUTT.md (Day 3 section)
```

---

### **Lesson 4: Lead Generation & Sales Integration**

```
Field Name                 | Value
---------------------------|----------------------------------
Lesson Title               | Lead Generation & Sales Integration
Lesson Code                | LNKD-001-L4
Course                     | LinkedIn Marketing Mastery
Day Number                 | 4
Duration (Minutes)         | 120
Learning Objectives        | Master B2B lead generation, create sales playbook, develop outreach
Key Concepts               | Lead generation, sales playbook, outreach sequences, KPIs
Exercises Count            | 2
Exercise 1 Title           | LinkedIn Lead Generation Strategy
Exercise 2 Title           | Sales Playbook (Connection to Meeting)
Deliverable                | Lead generation playbook + sales sequences
Success Criteria           | Lead gen strategy clear, playbook complete, sequences templated
Office Hours Time          | 1 PM - 1:30 PM
Mentor Lead                | Hamza Dar + Sanwa Ali
Difficulty Level           | Advanced
Status                     | Complete
Resource Link              | CLAUDE_FOR_SPECIALISTS_LINKEDIN_MARKETING_HAMZA_BUTT.md (Day 4 section)
```

---

### **Lesson 5: Capstone Project**

```
Field Name                 | Value
---------------------------|----------------------------------
Lesson Title               | Capstone: 90-Day LinkedIn Marketing Strategy
Lesson Code                | LNKD-001-L5
Course                     | LinkedIn Marketing Mastery
Day Number                 | 5
Duration (Minutes)         | 120
Learning Objectives        | Synthesize all learning into complete executable strategy
Key Concepts               | Strategy synthesis, calendar creation, execution planning, measurement
Exercises Count            | 1 (Capstone project)
Capstone Title             | 90-Day LinkedIn Marketing Strategy
Deliverable Pages          | 20-25 pages
Deliverables Included      | Strategy doc, 90-day calendar, 20 posts, templates, KPI framework
Success Criteria           | Complete strategy (20+ pages), all templates, executable plan
Office Hours Time          | 1 PM - 1:30 PM
Mentor Lead                | Sanwa Ali + Hamza Dar + Osman (optional)
Difficulty Level           | Advanced
Status                     | Complete
Resource Link              | CLAUDE_FOR_SPECIALISTS_LINKEDIN_MARKETING_HAMZA_BUTT.md (Day 5 section)
```

---

## 4️⃣ EXERCISES TABLE - DETAILED ENTRIES

**Create 10 records in "Exercises" table (2 per day):**

### **Exercise 1.1: LinkedIn Algorithm Mastery**

```
Field Name                 | Value
---------------------------|----------------------------------
Exercise Title             | LinkedIn Algorithm Mastery
Exercise Code              | LNKD-001-L1-E1
Course                     | LinkedIn Marketing Mastery
Lesson                     | LinkedIn Strategy for B2B Real Estate
Day Number                 | 1
Exercise Number            | 1 of 2
Difficulty                 | Intermediate
Time Estimate (Minutes)    | 45
Description                | Deep dive into LinkedIn algorithm factors, what drives reach
Learning Type              | Research + Analysis
Claude Prompt Included?    | Yes (detailed prompt provided)
Prompt Summary             | Analyze algorithm, identify opportunity areas, develop positioning
Expected Output            | Algorithm explanation, positioning analysis
Deliverable Format         | 1-2 pages
Rubric Score Weight        | 15%
Success Criteria           | Algorithm understanding clear, opportunity identified, positioning solid
Submission Format          | PDF + Google Doc (shared with mentor)
Due Date                   | Day 1, 12 PM (end of lesson)
Grading Rubric             | 1. Algorithm understanding (40%), 2. Opportunity identification (35%), 3. Writing quality (25%)
Sample Solution Link       | CLAUDE_FOR_SPECIALISTS_LINKEDIN_MARKETING_HAMZA_BUTT.md
Mentor Feedback            | [To be filled during course]
Pass/Fail Status           | [To be determined]
```

### **Exercise 1.2: Competitive Landscape Analysis**

```
Field Name                 | Value
---------------------------|----------------------------------
Exercise Title             | Competitive Landscape + Content Gap Analysis
Exercise Code              | LNKD-001-L1-E2
Course                     | LinkedIn Marketing Mastery
Lesson                     | LinkedIn Strategy for B2B Real Estate
Day Number                 | 1
Exercise Number            | 2 of 2
Difficulty                 | Intermediate
Time Estimate (Minutes)    | 45
Description                | Analyze 10 competitors, identify content gaps, develop strategy
Learning Type              | Research + Competitive Analysis
Claude Prompt Included?    | Yes
Prompt Summary             | Competitor analysis, gap identification, positioning strategy
Expected Output            | Competitor analysis, content gaps, unique positioning
Deliverable Format         | 3 pages (analysis + strategy)
Rubric Score Weight        | 15%
Success Criteria           | 10 competitors analyzed, gaps clear, positioning defensible
Submission Format          | PDF + Spreadsheet (competitive matrix)
Due Date                   | Day 1, 12 PM
Grading Rubric             | 1. Research depth (40%), 2. Analysis quality (35%), 3. Strategic thinking (25%)
Sample Solution Link       | CLAUDE_FOR_SPECIALISTS_LINKEDIN_MARKETING_HAMZA_BUTT.md
Mentor Feedback            | [To be filled during course]
Pass/Fail Status           | [To be determined]
```

---

*(Repeat similar structure for Exercises 2.1, 2.2, 3.1, 3.2, 4.1, 4.2, and 5.1)*

---

## 5️⃣ INTERN PROGRESS TABLE - TRACKING

**Create tracking record in "Intern Progress" table:**

```
Field Name                 | Value
---------------------------|----------------------------------
Intern                     | Hamza Butt (INST005)
Course                     | LinkedIn Marketing Mastery
Start Date                 | Aug 1, 2026
Current Status             | Not Started (Awaiting Aug 1)
Completion %               | 0%
Days Attended              | [Auto-populated]
Days Completed             | 0 of 5
Overall Score             | [To be calculated]
Lesson 1 Score            | [Pending]
Lesson 2 Score            | [Pending]
Lesson 3 Score            | [Pending]
Lesson 4 Score            | [Pending]
Capstone Score            | [Pending]
Engagement Level          | [Pending - High/Medium/Low]
Participation Quality     | [Pending - Excellent/Good/Fair/Needs Improvement]
Attendance                | 0/5 (0%)
Office Hours Attended     | 0/5
Exercises Submitted       | 0/10
Exercises Passed          | 0/10
Capstone Submitted?       | No
Capstone Score            | [Pending]
Capstone Status           | Not Started
Overall Grade             | [To be calculated: Average of all exercises + capstone]
Feedback Summary          | [To be filled by mentors]
Strengths Observed        | [To be filled]
Areas for Improvement     | [To be filled]
Post-Course Follow-up     | 90-day execution tracking
Projected Pipeline Value  | $1.5M+
Last Updated              | July 14, 2026
Next Review               | Aug 1, 2026 (course start)
```

---

## 6️⃣ CAPSTONE PROJECTS TABLE - ENTRY

**Create record in "Capstone Projects" table:**

```
Field Name                 | Value
---------------------------|----------------------------------
Capstone Title             | 90-Day LinkedIn Marketing Strategy for InstaSpace
Capstone Code              | LNKD-001-CAP
Intern                     | Hamza Butt (INST005)
Course                     | LinkedIn Marketing Mastery
Start Date                 | Aug 1, 2026
Due Date                   | Aug 5, 2026, 5 PM
Expected Pages             | 20-25
Expected Length (Words)    | 8,000-10,000
Project Type               | Strategic + Operational (Strategy doc + Templates + Calendar)
Deliverables Included      | 1. Strategy doc (5 pages), 2. 90-day calendar (1 page), 3. 90 posts (formatted), 4. Message templates (15 variations), 5. Lead gen playbook (8 pages), 6. Sales playbook (8 pages), 7. Analytics tracking sheet, 8. Weekly action plan
Success Criteria           | All components complete, strategy executable, templates ready to use
Rubric Criteria            | 1. Completeness (20%), 2. Actionability (25%), 3. Data-backed (20%), 4. Creativity (15%), 5. Writing quality (20%)
Pass Score                 | 8.5/10 minimum
Grading Rubric Link        | [See below for detailed rubric]
Mentor Review?             | Yes (Sanwa Ali + Hamza Dar)
Presentation Required?     | Optional (can present to team on Day 5)
Expected Business Impact   | $1.5M+ pipeline value, 3000+ LinkedIn followers, 45+ qualified meetings
Status                     | Not Started (Awaiting Aug 1)
Submission Link            | [To be provided on Day 5]
Final Score                | [Pending]
Feedback Summary           | [Pending]
Strengths Highlighted      | [Pending]
Improvement Suggestions    | [Pending]
Post-Delivery Support      | 90-day execution coaching from Sanwa + Hamza Dar
Follow-up Frequency        | Weekly check-ins (Fridays 4 PM)
```

---

## 7️⃣ OFFICE HOURS TABLE - SCHEDULE

**Create 5 records in "Office Hours" table (one per day):**

```
Field Name                 | Value
---------------------------|----------------------------------
Date                       | Aug 1, 2026 (repeat for Days 2-5)
Time                       | 1 PM - 1:30 PM
Duration (Minutes)         | 30
Course                     | LinkedIn Marketing Mastery
Intern                     | Hamza Butt (INST005)
Primary Mentor             | Sanwa Ali
Secondary Mentor           | Hamza Dar
Meeting Format             | Zoom (video call)
Zoom Link                  | [Insert meeting link]
Agenda                     | LinkedIn strategy discussion (Day 1 specific)
Day Focus                  | Day 1: Strategy + Positioning
Meeting Notes              | [To be filled during call]
Action Items               | [To be filled during call]
Questions Addressed        | [To be filled during call]
Recording Available?       | Yes (stored in shared folder)
Attendance                 | [To be marked: Present/Absent/Excused]
Intern Participation       | [To be marked: Excellent/Good/Fair/Minimal]
Mentor Feedback            | [To be filled after call]
Follow-up Items            | [If any, to be tracked]
Next Meeting               | Aug 2, 2026, 1 PM
Notes for Next Mentor      | [Handoff notes]
```

---

## 8️⃣ FEEDBACK LOG TABLE - TRACKING

**Create tracking record in "Feedback Log" table:**

```
Field Name                 | Value
---------------------------|----------------------------------
Intern                     | Hamza Butt (INST005)
Course                     | LinkedIn Marketing Mastery
Feedback Date              | [Auto-populate with today's date]
Feedback Source            | Sanwa Ali (primary), Hamza Dar (secondary)
Feedback Type              | Daily Progress Update (sent nightly)
Quality Score              | [1-10, filled daily by mentors]
Attendance Score           | [1-10, filled daily]
Engagement Level           | [1-10, filled daily]
Mood/Attitude              | [Emoji scale: 😄😊😐😟]
Blockers Identified        | [Any challenges faced]
Wins/Highlights            | [Positive accomplishments]
Next Day Focus             | [What to prioritize next]
Mentor Name                | Sanwa Ali
Date Submitted             | [Auto-generated]
Notes for Leadership       | [Key updates for Osman + Jybran]
Average Quality Score      | [Calculated across all days]
Course Completion Health   | [On track/At risk/Needs support]
```

---

## 9️⃣ WEEKLY METRICS TABLE - TRACKING

**Create record in "Weekly Metrics" table:**

```
Field Name                 | Value
---------------------------|----------------------------------
Week                       | Week 1 (Aug 1-5, 2026)
Intern                     | Hamza Butt (INST005)
Course                     | LinkedIn Marketing Mastery
Days Attended              | [Track daily, auto-sum]
Office Hours Attended      | [Track daily, auto-sum]
Exercises Submitted        | [Count, auto-sum]
Exercises Passed           | [Count, auto-sum]
Average Exercise Score     | [Auto-calculate]
Engagement Level           | [1-10 average]
Quality Metrics            | [Content quality rating]
Participation Quality      | [Excellent/Good/Fair]
Blockers/Challenges        | [List any issues]
Wins/Highlights            | [List successes]
Attendance Rate %          | [Calculated: 100% = 5/5]
Mentor Assessment          | [Overall week rating]
Capstone Progress %        | [Estimated completion]
Week Summary               | [Narrative summary from mentors]
Recommendations            | [For next week improvement]
Leadership Update          | [Sent to Osman/Jybran weekly]
Submitted By               | Sanwa Ali + Hamza Dar
Submission Date            | Every Friday
Next Week Focus            | [What to prioritize]
```

---

## 🔟 SETUP CHECKLIST

**Complete these steps to activate Hamza in Airtable:**

### **Step 1: Create Interns Record**
- [ ] Open "Interns" table in InstaSpace Learning Base
- [ ] Click "+" to add new record
- [ ] Fill fields per Section 1 above
- [ ] Save record (auto-generates Intern ID: INST005)

### **Step 2: Create Course Record**
- [ ] Open "Courses" table
- [ ] Click "+" to add new record
- [ ] Fill fields per Section 2 above
- [ ] Link to "LinkedIn Marketing Mastery" course
- [ ] Save record

### **Step 3: Create Lesson Records (5 total)**
- [ ] Open "Lessons" table
- [ ] Create 5 new records (one per day)
- [ ] Fill fields per Section 3 above
- [ ] Link each to "Hamza Butt" intern + "LinkedIn Marketing" course
- [ ] Save all records

### **Step 4: Create Exercise Records (10 total)**
- [ ] Open "Exercises" table
- [ ] Create 10 new records (2 per day)
- [ ] Fill fields per Section 4 above
- [ ] Link each to corresponding lesson
- [ ] Save all records

### **Step 5: Create Progress Tracker**
- [ ] Open "Intern Progress" table
- [ ] Create 1 new record
- [ ] Fill fields per Section 5 above
- [ ] Link to Hamza + LinkedIn Marketing course
- [ ] Save record

### **Step 6: Create Capstone Entry**
- [ ] Open "Capstone Projects" table
- [ ] Create 1 new record
- [ ] Fill fields per Section 6 above
- [ ] Link to Hamza + LinkedIn course
- [ ] Save record

### **Step 7: Create Office Hours (5 total)**
- [ ] Open "Office Hours" table
- [ ] Create 5 new records (one per day Aug 1-5)
- [ ] Fill fields per Section 7 above
- [ ] Link to Hamza + LinkedIn course
- [ ] Add Zoom links for each session
- [ ] Save all records

### **Step 8: Create Feedback Log**
- [ ] Open "Feedback Log" table
- [ ] Create 1 tracking record
- [ ] Fill fields per Section 8 above
- [ ] Link to Hamza + LinkedIn course
- [ ] Save record

### **Step 9: Create Weekly Metrics**
- [ ] Open "Weekly Metrics" table
- [ ] Create 1 record for Week 1 (Aug 1-5)
- [ ] Fill fields per Section 9 above
- [ ] Link to Hamza + LinkedIn course
- [ ] Save record

### **Step 10: Verify + Send Notifications**
- [ ] Confirm all records created + linked properly
- [ ] Send welcome email to hamza@myinstaspace.com
- [ ] Notify Sanwa Ali (primary mentor)
- [ ] Notify Hamza Dar (secondary mentor)
- [ ] Add to Slack #interns channel
- [ ] Schedule first office hours meeting (Aug 1, 1 PM)

---

## 🔒 ACCESS PERMISSIONS

**Who can access Hamza's records:**

| Role | Access Level | Fields Visible |
|------|--------------|---|
| Hamza Butt | Full | Lessons, exercises, feedback, progress |
| Sanwa Ali (Mentor) | Full | All + analytics, feedback, progress tracking |
| Hamza Dar (Co-Mentor) | Full | All + analytics, feedback, progress tracking |
| Osman (CEO) | Read | Progress, capstone, weekly metrics only |
| Jybran (COO) | Read | Progress, weekly metrics only |
| Other Interns | None | Can see only public course info |

---

## 📊 AUTOMATION RULES (Zapier)

**Set up these automations in Airtable:**

### **Automation 1: Daily Progress Notification**
- Trigger: New feedback logged (daily, 5 PM)
- Action: Send Slack message to #interns-progress with Hamza's daily score
- Message: "@Hamza - Day 1 update: Quality 9/10, Engagement 8/10, Attendance 100%"

### **Automation 2: Weekly Summary Email**
- Trigger: Every Friday at 4 PM
- Action: Send email to Sanwa + Hamza Dar with weekly metrics
- Content: Attendance, exercises, capstone progress, recommendations

### **Automation 3: Office Hours Reminder**
- Trigger: Daily at 12:30 PM (30 min before office hours)
- Action: Send Slack reminder to Hamza + mentors
- Message: "Office hours in 30 min! Zoom link: [link]"

### **Automation 4: Capstone Submission Notification**
- Trigger: Capstone submitted to Capstone Projects table
- Action: Email Sanwa + Hamza Dar + Osman
- Content: "Hamza's capstone submitted! Review and grade."

---

## ✅ FINAL CHECKLIST

**Before Aug 1, 2026 course start:**

- [ ] All Airtable records created (10 sections above)
- [ ] All links verified + working
- [ ] Hamza's login tested (hamza@myinstaspace.com)
- [ ] Mentors added to base + permissions set
- [ ] Zapier automations active
- [ ] Welcome email sent to Hamza
- [ ] Zoom links configured + tested
- [ ] Course materials linked (markdown file)
- [ ] Leadership dashboard updated (Osman/Jybran see Hamza)
- [ ] Slack channels updated (#interns, #growth-marketing)

---

**Status: ✅ READY FOR AUGUST 1 LAUNCH**

All Airtable infrastructure in place for Hamza Butt to begin LinkedIn Marketing Mastery course.

